package com.example.ktmedicare

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.annotation.RequiresApi

class FirebaseMessagingService :FirebaseMessagingService(){
    override fun onNewToken(p0: String) {
        super.onNewToken(p0)
        //토큰이 언제든 변경 될 수 있기떄문에 onNewToken을 갱신해주어야 한다.
    }

    override  fun OnMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)//-> androidManifest 에 등록
    }

    private fun createNotificationChannel() {
        if(Build.VERSION.SDK_INT >=  Build.VERSION_CODES.0) {
            val channel = NotificationChannel(CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT)
        }
    }

    companion object {
        private const val CHANNEL_NAME = "Emoji Party"
        private const val CHANNEL_DESCRIPTION = "Emoji Party를 위한 채널"
        private const val CHANNEL_ID = "Channel"
    }
}