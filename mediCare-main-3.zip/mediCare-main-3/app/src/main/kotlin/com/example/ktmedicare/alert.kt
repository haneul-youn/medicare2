package com.example.ktmedicare

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.CalendarView
import android.widget.TextView
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.medicare.R
import com.example.medicare.databinding.ActivityMainBinding
import java.text.DateFormat
import java.time.MonthDay
import java.util.*

class alert: AppCompatActivity(), TimePickerDialog.onTimeSetListener {
    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.alert_layout)

        binding = DataBindingUtil.setContentView(this, R.layout.alert_layout)

        binding.timeBtn.setOnClickListner {
            var timePicker = TimePickerFragment()
            timePicker.show(supportFragmentManager, "Time picker")
        }

        binding.alarmCancelBtn.setOnClickListener {
            cancleAlarm()
        }
    }

    override fun onTimeSet(timePicker: TimePicker?, hourOfDay: Int, minute: Int) {
        var c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, hourOfDay) //시
        c.set(Calendar.MINUTE, minute)//분
        c.set(Calendar.SECOND,0)//초

        updateTimeText(c)

        startAlarm(c)
    }

    //화면에 시간지정
    private fun updateTimeText(c:Calendar) {

        var curTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(c.time)

        binding.timeText.append("알람시간: ")
        binding.timeText.append(curTime)
    }

    //알람 설정
    private fun startAlarm(c: Calendar) {
        //알람 매니저
        var alarmMananger : AlarmManager = getSystemService (Context.ALARM_SERVICE)  as AlarmManager
        var intent = Intent(this, alertReceiver::class.java)

        //데이터 담기
        var curTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(c.time)
        intent.putExtra("time", curTime)

        var pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0)

        //설정 시간이 현재시간 이전이면 +1일
        if(c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE,1)
        }
        alarmMananger.setExact(AlarmManager.RTC_WAKEUP, c.timeInMillis, pendingIntent)
    }

    private fun cancleAlarm() {
        val alarmManager : AlarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        var intent = Intent(this, alertReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0)
        alarmManager.cancel(pendingIntent)
        binding.timeText.text = "알람 취소"
    }
}