package com.example.ktmedicare

class settings {
    private fun clickLogout() {

    }
    private fun clickAsk(){

    }

    private fun click() {

    }
}