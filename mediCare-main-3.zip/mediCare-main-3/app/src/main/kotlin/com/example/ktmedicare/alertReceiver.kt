package com.example.ktmedicare

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class alertReceiver:BroadcastReceiver(){
    override fun onReceive(context: Context?, intent: Intent?) {
        TODO("Not yet implemented")

        var notificationHelper: notificationHelper = notificationHelper(context)
        var nb : NotificationCompat.Builder = notificationHelper.getChannelNotification()

        notificationHelper.getManager().notify(1,nb.build())
    }
}